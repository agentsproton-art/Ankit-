import { CHECKLIST } from "./content.mjs";

// Each scene: (S, ch, D) => { html, js }
//   S  = scene start (s, absolute), ch = chunk start offsets (s, relative to scene), D = scene duration
// All motion lives on one paused GSAP timeline `tl` => deterministic, frame-seekable.
const P = (S, t) => +(S + t).toFixed(2);
const words = (t) => t.split(" ").map((w) => `<span class="kw">${w}</span>`).join(" ");
const hd = (n, t) => `<div class="hd"><b>${n}</b><span>${t}</span></div>`;
const box = (l, t, w, h, cls, inner, st = "") =>
  `<div class="${cls}" style="left:${l}px;top:${t}px;width:${w}px;height:${h}px;${st}">${inner}</div>`;
const WARN = (s = 56) => `<svg viewBox="0 0 48 48" width="${s}" height="${s}"><path d="M24 4L46 42H2Z" fill="#D64545"/><rect x="22" y="17" width="4" height="14" fill="#fff"/><circle cx="24" cy="36" r="2.6" fill="#fff"/></svg>`;
const CHECK = (s = 48, cls = "ck") => `<svg class="${cls}" viewBox="0 0 48 48" width="${s}" height="${s}"><circle cx="24" cy="24" r="22" fill="#2E9E6B"/><path d="M13 25L21 33L36 16" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const ARROW = (l, t) => `<svg class="ar abs" style="left:${l}px;top:${t}px" viewBox="0 0 60 30" width="60" height="30"><path d="M0 15H48M38 5L52 15L38 25" stroke="#C8A24A" stroke-width="5" fill="none" stroke-linecap="round"/></svg>`;
const person = (cls, body = "#2B5BA8", s = 1) =>
  `<svg class="${cls} abs" viewBox="0 0 120 220" width="${120 * s}" height="${220 * s}"><circle cx="60" cy="40" r="30" fill="#E8C27A"/><rect x="25" y="75" width="70" height="100" rx="28" fill="${body}"/><rect x="35" y="170" width="22" height="46" rx="8" fill="#1B2B4B"/><rect x="63" y="170" width="22" height="46" rx="8" fill="#1B2B4B"/></svg>`;
const banner = (cls, top, txt, red = false) => `<div class="banner ${cls}${red ? " r" : ""}" style="top:${top}px">${txt}</div>`;

export const scenes = [
// ---------------------------------------------------------------- 1 HOOK
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const risks = ["जाली बैनामा", "विवादित स्वामित्व", "अनधिकृत / अस्वीकृत कॉलोनी"];
  return { html: `
  <div class="abs" style="left:0;right:0;top:60px;text-align:center"><div class="big">${words("लखनऊ में ज़मीन खरीदने से पहले")}</div><div class="big gd">${words("14 दस्तावेज़ ज़रूर जाँचें")}</div></div>
  <svg class="abs plotsvg" style="left:90px;top:400px" viewBox="0 0 820 450" width="820" height="450">
    <rect x="0" y="330" width="820" height="120" fill="#16315F"/>
    <polygon points="140,330 700,330 760,430 80,430" fill="#2B4B80" stroke="#C8A24A" stroke-width="4" stroke-dasharray="14 8"/>
    <g class="sign"><rect x="560" y="170" width="12" height="200" fill="#8A6A2A"/><rect x="450" y="130" width="230" height="90" rx="10" fill="#C8A24A"/><text x="565" y="190" font-size="38" text-anchor="middle" fill="#0A1F44" font-weight="800">प्लॉट बिकाऊ</text></g>
  </svg>
  ${person("pp", "#2B5BA8", 1.5).replace('class="pp abs"', 'class="pp abs" style="left:170px;top:480px"')}
  ${risks.map((r, i) => box(1000, 410 + i * 150, 830, 125, "card rk red", `<div class="row">${WARN(64)}<span class="t">${r}</span></div>`)).join("")}
  `, js: `
  tl.from("#sc1 .kw",{y:90,opacity:0,rotateX:-70,stagger:.13,duration:.7,ease:"back.out(1.7)"},${P(S, .4)});
  tl.from("#sc1 .plotsvg",{opacity:0,duration:.8},${P(S, c(0) + .2)});
  tl.from("#sc1 .pp",{x:-320,duration:2.6,ease:"power2.out"},${P(S, c(0) + .4)});
  tl.from("#sc1 .sign",{scale:0,transformOrigin:"50% 100%",duration:.7,ease:"back.out(2)"},${P(S, c(0) + 2)});
  tl.from("#sc1 .rk",{x:140,opacity:0,stagger:1.3,duration:.7,ease:"power3.out"},${P(S, c(2) + .3)});
  tl.to("#sc1 .rk",{x:"+=10",repeat:3,yoyo:true,duration:.07,stagger:1.3},${P(S, c(2) + 1)});
  tl.to("#sc1 .pp",{y:-14,repeat:5,yoyo:true,duration:.35,ease:"sine.inOut"},${P(S, c(1) + .2)});` };
},
// ---------------------------------------------------------------- 2 TYPES
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const cols = [
    ["कृषि भूमि", ["राजस्व रिकॉर्ड में खेती के लिए दर्ज", "आवासीय उपयोग हेतु अनुमति देखनी पड़ सकती है", "सर्वाधिक सावधानी ज़रूरी"], "red"],
    ["स्वीकृत आवासीय प्लॉट", ["स्वीकृत लेआउट का हिस्सा", "सड़क व सीमाएँ तय", "भू-उपयोग आवासीय"], ""],
    ["डेवलपर प्रोजेक्ट", ["बिल्डर / कॉलोनाइज़र द्वारा बिक्री", "रेरा पंजीकरण व स्वीकृति देखें", "एग्रीमेंट की शर्तें पढ़ें"], ""],
  ];
  return { html: hd(2, "ज़मीन के तीन प्रकार") +
    cols.map((k, i) => box(80 + i * 600, 200, 570, 570, `card col k${i + 1} ${k[2]}`, `<h3>${k[0]}</h3>${k[1].map((x) => `<p class="ln">• ${x}</p>`).join("")}`)).join("") +
    banner("bn", 800, "पहले पहचानें: आपका प्लॉट किस श्रेणी में है?"), js: `
  tl.from("#sc2 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  ${[1, 2, 3].map((i) => `tl.from("#sc2 .col.k${i}",{y:90,opacity:0,duration:.8,ease:"power3.out"},${P(S, c(i))});
  tl.from("#sc2 .col.k${i} .ln",{x:-30,opacity:0,stagger:.7,duration:.5},${P(S, c(i) + .8)});`).join("\n")}
  tl.from("#sc2 .bn",{scale:.8,opacity:0,duration:.7,ease:"back.out(1.6)"},${P(S, c(4))});` };
},
// ---------------------------------------------------------------- 3 SALE DEED CHAIN
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const nodes = ["मूल खातेदार", "बैनामा – 1", "बैनामा – 2", "वर्तमान विक्रेता", "आप (खरीदार)"];
  return { html: hd(3, "बैनामा और स्वामित्व की कड़ी") +
    `<div class="abs miss" style="left:${70 + 2 * 370}px;top:250px;width:300px;text-align:center;color:#FF8A8A;font-size:40px;font-weight:800">गायब कड़ी?</div>` +
    nodes.map((n, i) => box(70 + i * 370, 330, 300, 200, `card nd ${i === 4 ? "gold" : ""}`, `<div class="ctr">${n}</div>`).replace('class="', `id="n3_${i}" class="`)).join("") +
    [0, 1, 2, 3].map((i) => ARROW(70 + i * 370 + 305, 415)).join("") +
    banner("b1", 610, "पंजीकरण अकेले ≠ विवाद-मुक्त टाइटल") + banner("b2", 740, "प्रमाणित प्रतियाँ माँगें  +  वकील से जाँच करवाएँ"), js: `
  tl.from("#sc3 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.from("#sc3 .nd",{y:60,opacity:0,stagger:.9,duration:.6},${P(S, c(1))});
  tl.from("#sc3 .ar",{scaleX:0,transformOrigin:"0 50%",stagger:.9,duration:.4},${P(S, c(1) + .5)});
  tl.from("#sc3 .miss",{opacity:0,y:-20,duration:.5},${P(S, c(2))});
  tl.to("#n3_2",{borderColor:"#D64545",backgroundColor:"rgba(214,69,69,.35)",duration:.5},${P(S, c(2))});
  tl.to("#n3_2",{x:"+=8",repeat:5,yoyo:true,duration:.06},${P(S, c(2) + .5)});
  tl.from("#sc3 .b1",{scale:.85,opacity:0,duration:.6,ease:"back.out(1.5)"},${P(S, c(3))});
  tl.from("#sc3 .b2",{y:40,opacity:0,duration:.6},${P(S, c(4))});` };
},
// ---------------------------------------------------------------- 4 KHATAUNI / KHASRA
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const rows = [["खाता संख्या", "XXX"], ["खसरा संख्या", "XXXX"], ["रकबा", "X.XXX हे."], ["भूमिधर / खातेदार", "(नाम)"]];
  const polys = ["40,40 300,30 320,200 50,210", "300,30 560,50 580,220 320,200", "560,50 860,40 850,230 580,220", "50,210 320,200 340,380 60,400", "320,200 580,220 600,390 340,380", "580,220 850,230 860,400 600,390"];
  return { html: hd(4, "खतौनी और खसरा") +
    box(80, 190, 780, 580, "card kh", `<h3>खतौनी (नमूना चित्र)</h3>${rows.map((r, i) => `<div class="fr"><span>${r[0]}</span><b>${r[1]}</b>${CHECK(40, "ck ck" + i)}</div>`).join("")}`) +
    `<svg class="abs cmap" style="left:930px;top:190px" viewBox="0 0 900 500" width="900" height="500">
      ${polys.map((p, i) => `<polygon class="pg ${i === 4 ? "hl" : ""}" points="${p}" fill="rgba(255,255,255,.08)" stroke="#8FA6D0" stroke-width="3"/>`).join("")}
      <rect x="40" y="400" width="820" height="70" fill="#55627A" opacity=".7"/><text x="450" y="447" font-size="34" fill="#fff" text-anchor="middle">सड़क</text>
      <text class="lb" x="470" y="300" font-size="40" font-weight="800" fill="#0A1F44" text-anchor="middle">खसरा सं. XXXX</text>
    </svg>` + banner("bn", 800, "खतौनी / म्यूटेशन ≠ स्वामित्व का अंतिम प्रमाण", true), js: `
  tl.from("#sc4 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.from("#sc4 .kh",{x:-80,opacity:0,duration:.8},${P(S, c(0) + 2)});
  tl.from("#sc4 .fr",{x:-40,opacity:0,stagger:.7,duration:.5},${P(S, c(1))});
  tl.from("#sc4 .pg",{opacity:0,scale:.9,transformOrigin:"50% 50%",stagger:.25,duration:.5},${P(S, c(2))});
  tl.to("#sc4 .hl",{fill:"rgba(200,162,74,.85)",stroke:"#C8A24A",duration:.6},${P(S, c(2) + 2)});
  tl.from("#sc4 .lb",{opacity:0,duration:.5},${P(S, c(2) + 2.4)});
  tl.from("#sc4 .ck",{scale:0,stagger:.5,duration:.4,ease:"back.out(2.5)"},${P(S, c(3) + .3)});
  tl.from("#sc4 .bn",{scale:.85,opacity:0,duration:.7,ease:"back.out(1.5)"},${P(S, c(4) + .3)});` };
},
// ---------------------------------------------------------------- 5 ENCUMBRANCE / DISPUTES
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const cs = [["बंधक / बैंक लोन", "ऋण या गिरवी का रिकॉर्ड"], ["न्यायालय विवाद", "लंबित मुकदमा / दावा"], ["स्थगन आदेश", "निषेधाज्ञा (इंजंक्शन)"]];
  return { html: hd(5, "ऋणभार और विवाद") +
    cs.map((k, i) => box(80 + i * 600, 190, 570, 260, "card ec red", `<div class="row">${WARN(60)}<h3 style="margin:0">${k[0]}</h3></div><p class="ln">${k[1]}</p>`)).join("") +
    box(260, 520, 1400, 130, "card srch", `<div class="row"><svg viewBox="0 0 60 60" width="60" height="60"><circle cx="25" cy="25" r="16" stroke="#C8A24A" stroke-width="6" fill="none"/><path d="M37 37L54 54" stroke="#C8A24A" stroke-width="7" stroke-linecap="round"/></svg><span class="t">पंजीकृत दस्तावेज़ों की खोज / ऋणभार प्रमाणपत्र</span></div>`) +
    box(260, 670, 1400, 100, "card res", `<div class="row"><span class="t">नमूना चित्रण: खोज परिणाम की समीक्षा  →  वकील से पुष्टि</span></div>`) +
    banner("bn", 800, "हर विवाद रिकॉर्ड में नहीं दिखता: लिखित घोषणा + स्थानीय जाँच", true), js: `
  tl.from("#sc5 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.from("#sc5 .ec",{y:70,opacity:0,stagger:.5,duration:.7},${P(S, c(0) + 2)});
  tl.from("#sc5 .srch",{scaleX:0,transformOrigin:"0 50%",duration:.8},${P(S, c(1))});
  tl.from("#sc5 .srch .t",{opacity:0,duration:.6},${P(S, c(1) + .6)});
  tl.from("#sc5 .res",{y:40,opacity:0,duration:.6},${P(S, c(1) + 3)});
  tl.to("#sc5 .ec",{borderColor:"#FF8A8A",repeat:3,yoyo:true,duration:.3,stagger:.3},${P(S, c(2))});
  tl.from("#sc5 .bn",{scale:.85,opacity:0,duration:.7,ease:"back.out(1.5)"},${P(S, c(3))});` };
},
// ---------------------------------------------------------------- 6 AUTHORITY APPROVAL
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  let ok = `<svg class="abs lay1" style="left:80px;top:230px" viewBox="0 0 860 520" width="860" height="520"><rect width="860" height="520" fill="none" stroke="#2E9E6B" stroke-width="5"/><rect x="0" y="230" width="860" height="50" fill="#55627A"/><rect x="405" y="0" width="50" height="520" fill="#55627A"/>`;
  for (const x0 of [20, 115, 210, 305, 475, 570, 665, 760]) for (const y0 of [20, 120, 300, 400]) ok += `<rect class="pl" x="${x0}" y="${y0}" width="80" height="90" fill="rgba(46,158,107,.28)" stroke="#9FE0C0" stroke-width="2"/>`;
  ok += `<text x="430" y="262" font-size="26" fill="#fff" text-anchor="middle" font-weight="700">सड़क</text></svg>`;
  const bad = ["30,30 230,60 200,230 40,200", "260,40 430,20 450,190 230,250", "480,50 820,30 800,210 520,230", "40,290 250,260 280,470 60,490", "300,300 520,280 560,500 290,480", "580,300 830,290 820,500 600,490"];
  const un = `<svg class="abs lay2" style="left:980px;top:230px" viewBox="0 0 860 520" width="860" height="520"><rect width="860" height="520" fill="none" stroke="#D64545" stroke-width="5" stroke-dasharray="16 10"/>${bad.map((p) => `<polygon class="bp" points="${p}" fill="rgba(214,69,69,.2)" stroke="#FF8A8A" stroke-width="2"/>`).join("")}<text x="430" y="270" font-size="120" fill="#FF8A8A" text-anchor="middle" font-weight="800" class="qm">?</text></svg>`;
  return { html: hd(6, "प्राधिकरण से स्वीकृति") + ok + un +
    `<div class="tag abs t1" style="left:80px;top:180px;color:#9FE0C0">स्वीकृत लेआउट: सीमा • सड़क • पहुँच मार्ग</div><div class="tag abs t2" style="left:980px;top:180px;color:#FF8A8A">अप्रमाणित लेआउट: सावधान</div>` +
    `<div class="stamp abs">प्राधिकरण से पुष्टि करें</div>`, js: `
  tl.from("#sc6 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.from("#sc6 .lay1",{opacity:0,duration:.6},${P(S, c(1))});
  tl.from("#sc6 .t1",{opacity:0,duration:.5},${P(S, c(1))});
  tl.from("#sc6 .pl",{scale:0,transformOrigin:"50% 50%",stagger:.05,duration:.3},${P(S, c(1) + .6)});
  tl.from("#sc6 .stamp",{scale:3,opacity:0,rotation:-14,duration:.5,ease:"power4.in"},${P(S, c(2) + 1)});
  tl.from("#sc6 .lay2",{opacity:0,duration:.6},${P(S, c(3))});
  tl.from("#sc6 .t2",{opacity:0,duration:.5},${P(S, c(3))});
  tl.from("#sc6 .bp",{opacity:0,stagger:.3,duration:.4},${P(S, c(3) + .6)});
  tl.from("#sc6 .qm",{scale:0,transformOrigin:"50% 50%",duration:.6,ease:"back.out(3)"},${P(S, c(3) + 2.5)});` };
},
// ---------------------------------------------------------------- 7 LAND USE
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const field = [0, 1, 2, 3, 4, 5].map((i) => `<path d="M30 ${120 + i * 52}H500" stroke="#7FB069" stroke-width="10" stroke-linecap="round"/>`).join("");
  const houses = [0, 1, 2].map((i) => `<g class="hs"><rect x="${40 + i * 160}" y="260" width="120" height="110" fill="#E8E1D0"/><polygon points="${30 + i * 160},260 ${100 + i * 160},190 ${170 + i * 160},260" fill="#C8A24A"/></g>`).join("");
  return { html: hd(7, "भू-उपयोग: कृषि बनाम आवासीय") +
    `<svg class="abs fld" style="left:70px;top:200px" viewBox="0 0 540 420" width="540" height="420"><rect width="540" height="420" rx="20" fill="rgba(80,140,70,.3)" stroke="#7FB069" stroke-width="4"/>${field}<text x="270" y="400" font-size="40" fill="#fff" text-anchor="middle" font-weight="800">कृषि भूमि</text></svg>` +
    `<svg class="abs gate" style="left:690px;top:260px" viewBox="0 0 540 300" width="540" height="300"><circle cx="270" cy="130" r="95" fill="rgba(200,162,74,.2)" stroke="#C8A24A" stroke-width="6" stroke-dasharray="16 10"/><text x="270" y="165" font-size="110" fill="#C8A24A" text-anchor="middle" font-weight="800">?</text><text x="270" y="270" font-size="34" fill="#fff" text-anchor="middle">भू-उपयोग परिवर्तन / अनुमति</text></svg>` +
    `<svg class="abs rsd" style="left:1300px;top:200px" viewBox="0 0 540 420" width="540" height="420"><rect width="540" height="420" rx="20" fill="rgba(43,91,168,.3)" stroke="#8FA6D0" stroke-width="4"/>${houses}<rect x="20" y="370" width="500" height="10" fill="#55627A"/><text x="270" y="410" font-size="40" fill="#fff" text-anchor="middle" font-weight="800" dy="-6">आवासीय उपयोग</text></svg>` +
    banner("b1", 650, "मास्टर प्लान में उस क्षेत्र का भू-उपयोग भी देखें") + banner("b2", 770, "बिना अनुमति निर्माण: नक्शा न पास होना, जुर्माना, कार्रवाई का जोखिम", true), js: `
  tl.from("#sc7 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.from("#sc7 .fld",{x:-100,opacity:0,duration:.8},${P(S, c(0))});
  tl.from("#sc7 .rsd",{x:100,opacity:0,duration:.8},${P(S, c(0) + 1.5)});
  tl.from("#sc7 .hs",{y:50,opacity:0,stagger:.4,duration:.5},${P(S, c(0) + 2.3)});
  tl.from("#sc7 .gate",{scale:0,transformOrigin:"50% 40%",duration:.7,ease:"back.out(2)"},${P(S, c(1))});
  tl.to("#sc7 .gate circle",{rotation:360,transformOrigin:"50% 50%",duration:6,ease:"none"},${P(S, c(1))});
  tl.from("#sc7 .b1",{y:40,opacity:0,duration:.6},${P(S, c(2))});
  tl.from("#sc7 .b2",{y:40,opacity:0,duration:.6},${P(S, c(3))});` };
},
// ---------------------------------------------------------------- 8 SELLER VERIFICATION
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const cs = [["पहचान मिलान", ["आधार / पैन बनाम रिकॉर्ड का नाम", "फ़ोटो व हस्ताक्षर मिलाएँ"]], ["सह-स्वामित्व", ["सभी सह-स्वामी पहचानें", "सबकी सहमति व हस्ताक्षर"]], ["वरासत व वारिस", ["वरासत का रिकॉर्ड", "सभी कानूनी वारिस"]], ["पावर ऑफ़ अटॉर्नी", ["असली व अधिकार पर्याप्त?", "रद्द / समाप्त तो नहीं?"]]];
  return { html: hd(8, "विक्रेता का सत्यापन") +
    cs.map((k, i) => box(60 + i * 460, 210, 420, 560, `card sv k${i + 1}`, `<h3>${k[0]}</h3>${k[1].map((x) => `<p class="ln">• ${x}</p>`).join("")}<div class="ckw">${CHECK(70, "ck")}</div>`)).join(""), js: `
  tl.from("#sc8 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  ${[1, 2, 3, 4].map((i) => `tl.from("#sc8 .sv.k${i}",{y:80,opacity:0,duration:.7},${P(S, c(i))});
  tl.from("#sc8 .sv.k${i} .ck",{scale:0,duration:.5,ease:"back.out(3)"},${P(S, c(i) + 3)});`).join("\n")}` };
},
// ---------------------------------------------------------------- 9 PHYSICAL INSPECTION
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const pts = [[200, 120], [700, 100], [720, 380], [180, 400], [200, 120]];
  const leg = Math.max(1.2, (c(2) - c(1)) / 4);
  const items = ["माप: खसरा / नक्शे से मिलान", "चारों सीमा-चिह्न पहचानें", "अतिक्रमण / कब्ज़ा नहीं?", "कानूनी पहुँच मार्ग"];
  return { html: hd(9, "मौके पर निरीक्षण") +
    `<svg class="abs ps" style="left:60px;top:190px" viewBox="0 0 900 560" width="900" height="560">
      <rect x="0" y="440" width="900" height="70" fill="#55627A"/><text x="450" y="487" font-size="34" fill="#fff" text-anchor="middle">मुख्य सड़क / पहुँच मार्ग</text>
      <polygon id="s9poly" points="${pts.slice(0, 4).map((p) => p.join(",")).join(" ")}" fill="rgba(200,162,74,.18)" stroke="#C8A24A" stroke-width="7" style="stroke-dasharray:1900;stroke-dashoffset:0"/>
      <text class="dm" x="450" y="82" font-size="30" fill="#fff" text-anchor="middle">लंबाई __ फ़ीट</text>
      <text class="dm" x="800" y="250" font-size="30" fill="#fff" text-anchor="middle">चौड़ाई __ फ़ीट</text>
      <text class="dm" x="100" y="260" font-size="28" fill="#8FA6D0" text-anchor="middle">पड़ोसी</text>
      <text class="dm" x="450" y="250" font-size="40" fill="#C8A24A" text-anchor="middle" font-weight="800">प्लॉट</text>
      <path class="rd" d="M450 400V440" stroke="#2E9E6B" stroke-width="8" stroke-dasharray="10 8"/>
      <circle id="s9dot" cx="200" cy="120" r="17" fill="#fff" stroke="#D64545" stroke-width="7"/>
    </svg>` +
    items.map((x, i) => box(1000, 220 + i * 140, 860, 110, `card chk k${i + 1}`, `<div class="row">${CHECK(52, "ck")}<span class="t">${x}</span></div>`)).join(""), js: `
  tl.from("#sc9 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.from("#sc9 .ps",{opacity:0,duration:.7},${P(S, c(0) + 1)});
  tl.from("#s9poly",{strokeDashoffset:1900,duration:2.2,ease:"power1.inOut"},${P(S, c(1))});
  ${pts.slice(1).map((p, i) => `tl.to("#s9dot",{attr:{cx:${p[0]},cy:${p[1]}},duration:${leg.toFixed(2)},ease:"power1.inOut"},${P(S, c(1) + 1 + i * leg)});`).join("\n  ")}
  tl.from("#sc9 .dm",{opacity:0,stagger:.5,duration:.4},${P(S, c(1) + 1.5)});
  tl.from("#sc9 .rd",{opacity:0,duration:.5},${P(S, c(3))});
  ${[0, 1, 2, 3].map((i) => `tl.from("#sc9 .chk.k${i + 1}",{x:90,opacity:0,duration:.6},${P(S, c(Math.min(i + 1, ch.length - 1)) + .2)});`).join("\n  ")}` };
},
// ---------------------------------------------------------------- 10 SPECIAL CASES
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const cs = [["विरासत में मिली ज़मीन", "वारिसों की सूची • वरासत रिकॉर्ड • सभी की सहमति"], ["बंधक रखी संपत्ति", "बैंक की अनापत्ति • ऋण-मुक्ति • मूल कागज़ात की वापसी"], ["सरकारी / प्राधिकरण आवंटित", "आवंटन की शर्तें • लीज़ या फ्रीहोल्ड • हस्तांतरण की अनुमति"], ["डेवलपर प्रोजेक्ट", "रेरा पंजीकरण • स्वीकृत नक्शा • एग्रीमेंट की शर्तें"]];
  return { html: hd(10, "विशेष स्थितियों में अतिरिक्त जाँच") +
    cs.map((k, i) => box(60 + (i % 2) * 920, 190 + Math.floor(i / 2) * 300, 880, 270, `card sp k${i + 1}`, `<h3>${k[0]}</h3><p class="ln">${k[1]}</p>`)).join("") +
    banner("bn", 800, "कुछ श्रेणियों की ज़मीन पर हस्तांतरण की पाबंदियाँ हो सकती हैं: वकील से पूछें"), js: `
  tl.from("#sc10 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  ${[1, 2, 3, 4].map((i) => `tl.from("#sc10 .sp.k${i}",{scale:.85,opacity:0,transformOrigin:"50% 50%",duration:.7,ease:"back.out(1.4)"},${P(S, c(i))});`).join("\n  ")}
  tl.from("#sc10 .bn",{y:40,opacity:0,duration:.6},${P(S, c(5))});` };
},
// ---------------------------------------------------------------- 11 REGISTRATION AND COSTS
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const st = ["सर्किल रेट देखें", "स्टांप शुल्क", "पंजीकरण शुल्क", "रसीदें सँभालें"];
  return { html: hd(11, "पंजीकरण और खर्च") +
    st.map((s, i) => box(60 + i * 470, 200, 400, 170, `card stp k${i + 1}`, `<div class="ctr">${s}</div>`)).join("") +
    [0, 1, 2].map((i) => ARROW(60 + i * 470 + 405, 270)).join("") +
    box(540, 430, 840, 330, "card rcpt", `<h3>भुगतान रसीद (नमूना)</h3><div class="fr"><span>स्टांप शुल्क</span><b>₹ ____</b></div><div class="fr"><span>पंजीकरण शुल्क</span><b>₹ ____</b></div><div class="fr"><span>आधिकारिक माध्यम से भुगतान</span>${CHECK(40, "ck")}</div>`) +
    `<div class="card chip1 abs" style="left:60px;top:470px;width:420px;height:200px"><div class="ctr">दरें बदलती हैं: वर्तमान दरें आधिकारिक स्रोत पर देखें</div></div>` +
    `<div class="card chip2 abs" style="left:1440px;top:470px;width:420px;height:200px"><div class="ctr">पंजीकरण के बाद दाखिल-खारिज करवाएँ</div></div>` +
    banner("bn", 800, "बड़ा भुगतान ट्रेस होने वाले माध्यम से • बैनामे में विवरण सही हो"), js: `
  tl.from("#sc11 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  ${[0, 1, 2, 3].map((i) => `tl.from("#sc11 .stp.k${i + 1}",{y:-60,opacity:0,duration:.6},${P(S, c(Math.min(i, 3)) + .2)});`).join("\n  ")}
  tl.from("#sc11 .ar",{scaleX:0,transformOrigin:"0 50%",stagger:.5,duration:.4},${P(S, c(0) + .8)});
  tl.from("#sc11 .chip1",{x:-80,opacity:0,duration:.6},${P(S, c(1) + 1)});
  tl.from("#sc11 .rcpt",{y:70,opacity:0,duration:.7},${P(S, c(2))});
  tl.from("#sc11 .rcpt .fr",{x:-30,opacity:0,stagger:.5,duration:.4},${P(S, c(2) + .6)});
  tl.from("#sc11 .chip2",{x:80,opacity:0,duration:.6},${P(S, c(3))});
  tl.from("#sc11 .bn",{y:40,opacity:0,duration:.6},${P(S, c(4))});` };
},
// ---------------------------------------------------------------- 12 RED FLAGS
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const fl = [["दस्तावेज़ गायब", "केवल फ़ोटो कॉपी, मूल कागज़ से परहेज़"], ["रिकॉर्ड मेल नहीं खाते", "नाम / खसरा / रकबा में अंतर"], ["जल्दबाज़ी में भुगतान", "“आज ही एडवांस दो” का दबाव"], ["विवादित टाइटल", "मुकदमा या परिवार की आपत्ति"]];
  return { html: `<div class="vig abs" style="inset:0;background:radial-gradient(circle,transparent 40%,rgba(214,69,69,.55))"></div>` + hd(12, "खतरे के संकेत") +
    fl.map((k, i) => box(60 + i * 460, 230, 420, 440, `card fg red k${i + 1}`, `<div class="ctr2">${WARN(110)}<h3>${k[0]}</h3><p class="ln">${k[1]}</p></div>`)).join("") +
    banner("bn", 740, "रुकिए  •  जाँचिए  •  फिर भुगतान", true), js: `
  tl.from("#sc12 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  tl.fromTo("#sc12 .vig",{opacity:0},{opacity:1,duration:.6,yoyo:true,repeat:5},${P(S, .3)});
  ${[1, 2, 3, 4].map((i) => `tl.from("#sc12 .fg.k${i}",{y:-120,opacity:0,duration:.5,ease:"bounce.out"},${P(S, c(i))});
  tl.to("#sc12 .fg.k${i}",{x:"+=10",repeat:5,yoyo:true,duration:.06},${P(S, c(i) + .6)});`).join("\n  ")}
  tl.from("#sc12 .bn",{scale:.7,opacity:0,duration:.6,ease:"back.out(2)"},${P(S, c(5))});` };
},
// ---------------------------------------------------------------- 13 FINAL CHECKLIST
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  const col = { "आवश्यक": "#2E9E6B", "सुझावित": "#C8A24A", "विशेष स्थिति": "#4F86D6" };
  return { html: hd(13, "14 बातों की अंतिम सूची") +
    CHECKLIST.map((k, i) => box(58 + (i % 7) * 260, 180 + Math.floor(i / 7) * 340, 245, 320, `card ci k${i + 1}`, `<div class="num2">${i + 1}</div><div class="ct">${k[0]}</div><div class="chipt" style="background:${col[k[1]]}">${k[1]}</div>${CHECK(46, "ck")}`)).join("") +
    `<div class="abs legend" style="left:0;right:0;top:860px;text-align:center;font-size:30px"><span style="color:#2E9E6B">● आवश्यक</span> &nbsp;&nbsp; <span style="color:#C8A24A">● सुझावित जाँच</span> &nbsp;&nbsp; <span style="color:#4F86D6">● विशेष स्थिति में</span></div>`, js: `
  tl.from("#sc13 .hd",{x:-60,opacity:0,duration:.7},${P(S, .3)});
  ${CHECKLIST.map((_, i) => `tl.from("#sc13 .ci.k${i + 1}",{scale:.6,opacity:0,y:50,duration:.5,ease:"back.out(1.8)"},${P(S, c(i + 1))});
  tl.from("#sc13 .ci.k${i + 1} .ck",{scale:0,duration:.4,ease:"back.out(3)"},${P(S, c(i + 1) + 1.1)});`).join("\n  ")}
  tl.from("#sc13 .legend",{opacity:0,y:20,duration:.6},${P(S, c(15))});` };
},
// ---------------------------------------------------------------- 14 CONCLUSION
(S, ch) => {
  const c = (i) => ch[Math.min(i, ch.length - 1)];
  return { html: `<div class="abs" style="left:0;right:0;top:70px;text-align:center"><div class="big gd">${words("एडवांस से पहले")}</div><div class="big">${words("स्वतंत्र प्रॉपर्टी वकील")}</div></div>` +
    `<div class="abs" style="left:300px;top:640px;width:1320px;height:24px;background:#8A6A2A;border-radius:10px" class="tbl"></div>` +
    person("buyer", "#2B5BA8", 1.6).replace('class="buyer abs"', 'class="buyer abs" style="left:380px;top:360px"') +
    person("lawyer", "#1B2B4B", 1.6).replace('class="lawyer abs"', 'class="lawyer abs" style="left:1330px;top:360px"') +
    `<div class="card doc abs" style="left:700px;top:430px;width:520px;height:210px"><div class="ctr" style="font-size:34px">टाइटल रिपोर्ट<br><small style="font-size:26px;opacity:.8">दस्तावेज़ों की जाँच</small></div></div>` +
    `<div class="stamp abs st2" style="left:880px;top:560px">वकील की सलाह</div>` +
    banner("b1", 720, "स्वतंत्र = विक्रेता / दलाल / बिल्डर से असंबद्ध") +
    banner("b2", 820, "राजस्व रिकॉर्ड ≠ स्वामित्व  •  पंजीकरण ≠ विवाद-मुक्त टाइटल", true) +
    `<div class="abs disc" style="left:0;right:0;top:35px;text-align:center;font-size:26px;opacity:.7">सामान्य जानकारी • कानूनी सलाह नहीं</div>` +
    `<div class="abs thx" style="left:0;right:0;top:420px;text-align:center;font-size:150px;font-weight:800;color:#C8A24A;text-shadow:0 8px 40px #000">धन्यवाद</div>`, js: `
  tl.from("#sc14 .kw",{y:90,opacity:0,stagger:.2,duration:.7,ease:"back.out(1.7)"},${P(S, .4)});
  tl.from("#sc14 .buyer",{x:-300,duration:1.6,ease:"power2.out"},${P(S, c(0) + .5)});
  tl.from("#sc14 .lawyer",{x:300,duration:1.6,ease:"power2.out"},${P(S, c(0) + .5)});
  tl.from("#sc14 .doc",{y:-80,opacity:0,duration:.8},${P(S, c(0) + 2.5)});
  tl.from("#sc14 .b1",{y:40,opacity:0,duration:.6},${P(S, c(1))});
  tl.from("#sc14 .st2",{scale:3,opacity:0,rotation:-14,duration:.5,ease:"power4.in"},${P(S, c(2) + 1)});
  tl.from("#sc14 .b2",{scale:.85,opacity:0,duration:.7,ease:"back.out(1.5)"},${P(S, c(3))});
  tl.from("#sc14 .disc",{opacity:0,duration:.6},${P(S, c(4))});
  tl.to("#sc14 .buyer, #sc14 .lawyer, #sc14 .doc, #sc14 .b1, #sc14 .b2, #sc14 .st2, #sc14 .big",{opacity:0,duration:.8},${P(S, c(5) - .2)});
  tl.from("#sc14 .thx",{scale:.6,opacity:0,duration:1,ease:"back.out(1.7)"},${P(S, c(5))});` };
},
];
