# Lucknow Mein Zameen Kharidne Se Pehle 14 Documents Zaroor Check Karein
Animated Hindi explainer, 1920×1080 @ 30 fps, 14 scenes, ~10 min. Framework: **HyperFrames** (HTML + GSAP, one paused timeline → deterministic frame-by-frame render).

## Status (what is and isn't done)
| Item | Status |
|---|---|
| 14 scenes, animations, Hindi captions (121, timed), SRT file | Done, generated into `index.html` / `build/subtitles.srt` |
| Script + GSAP syntax check, all 270 selectors matched to elements | Verified |
| Background music | Done: original synthesized ambient pad (`npm run music`), no licensing issue, plays at 12% volume |
| Hindi narration audio | **Not generated** (no TTS/network in the build sandbox). Run `npm run tts` or add your own recordings |
| MP4 render | **Not rendered** (no Chromium/network in the sandbox). Run `npm run render` on your machine |
Until narration exists, caption timing uses an estimate; after `npm run tts` (or `npm run measure`) all timings and the total length follow the real audio.

## Requirements
Node 22+, FFmpeg, Python 3.9+ (only for narration). Internet on first run (HyperFrames via npx, GSAP + Noto Sans Devanagari from CDN; for offline use put `NotoSansDevanagari.ttf` in `assets/fonts/`).

## Steps
```bash
pip install edge-tts
npm run music        # only if assets/music/bg.mp3 is missing
npm run tts          # Hindi voice (hi-IN-SwaraNeural; VOICE=hi-IN-MadhurNeural for male) + rebuild
npm run preview      # HyperFrames Studio, check timing
npm run render       # -> output.mp4
npm run verify       # ffprobe: 1080p/30fps, video + audio tracks, decodes cleanly
```
**Own voiceover instead:** record one file per chunk named `assets/audio/sNN_cMM.mp3` (see `src/content.mjs`; chunk = one string), then `npm run measure`. Missing files are skipped with a warning; the video still builds without them.

## Files
`src/content.mjs` narration + checklist · `src/scenes.mjs` visuals/animation · `src/style.css` · `scripts/build.mjs` generates `index.html` · edit content, then `npm run build`.

## Notes on HyperFrames
Written from the official quickstart (root `data-composition-id`, `class="clip"` + `data-start/duration/track-index`, paused GSAP timeline on `window.__timelines`). The `<audio data-*>` attributes and `data-volume` are my best reading of the media docs and were **not testable here**; if preview shows silence, compare with the HyperFrames audio guide (`npx hyperframes init` example) and adjust the audio line in `scripts/build.mjs`. If HyperFrames fails on your setup, the same `src/` content ports directly to Remotion.

## Content accuracy: please verify before publishing
General educational content, not legal advice. Official starting points: upbhulekh.gov.in, igrsup.gov.in, ldalucknow.in. Not verifiable offline here, so the script deliberately avoids specific rates, fees, portal button names and section numbers. Have a UP property lawyer check in particular: (1) land-use conversion wording under the UP Revenue Code (scene 7), (2) allotted-land and transfer-restriction statements (scene 10), (3) what the registration portal currently offers for encumbrance search (scene 5), (4) which areas fall under LDA vs other bodies (scene 6). Mandatory vs recommended vs special-case labels are on the scene-13 cards.
