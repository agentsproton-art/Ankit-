#!/usr/bin/env bash
# Confirms the MP4 exists and has 1920x1080@30 video + an audio track.
f="${1:-output.mp4}"
[ -s "$f" ] || { echo "FAIL: $f missing or empty"; exit 1; }
ffprobe -v error -show_entries stream=codec_type,codec_name,width,height,r_frame_rate,duration -of default=nw=1 "$f"
ffmpeg -v error -i "$f" -f null - && echo "decode OK"
ffprobe -v error -select_streams a -show_entries stream=codec_type -of csv=p=0 "$f" | grep -q audio && echo "audio track present" || echo "WARNING: no audio track"
