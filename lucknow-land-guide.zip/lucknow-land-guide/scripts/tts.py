#!/usr/bin/env python3
"""Generate Hindi narration per chunk with edge-tts (free, needs internet), or just measure existing recordings.
  pip install edge-tts
  python3 scripts/tts.py            # synthesize all chunks -> assets/audio/sNN_cMM.mp3, then measure
  python3 scripts/tts.py --measure  # only measure durations of files already in assets/audio (e.g. your own recordings)
Voice: hi-IN-SwaraNeural (female) / hi-IN-MadhurNeural (male). Override: VOICE=hi-IN-MadhurNeural
"""
import asyncio, json, os, re, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIO = os.path.join(ROOT, "assets", "audio"); os.makedirs(AUDIO, exist_ok=True)
VOICE = os.environ.get("VOICE", "hi-IN-SwaraNeural"); RATE = os.environ.get("RATE", "-4%")

def chunks():  # parse src/content.mjs without needing node
    src = open(os.path.join(ROOT, "src", "content.mjs"), encoding="utf8").read()
    out = []
    for m in re.finditer(r"\{ n: (\d+), title: \"[^\"]*\", chunks: \[(.*?)\]\}", src, re.S):
        n = int(m.group(1))
        for i, t in enumerate(re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(2))):
            out.append((f"s{n:02d}_c{i:02d}", t))
    return out

def dur(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], capture_output=True, text=True)
    return float(r.stdout.strip())

async def synth(items):
    import edge_tts
    for cid, text in items:
        p = os.path.join(AUDIO, cid + ".mp3")
        if os.path.exists(p) and os.path.getsize(p) > 1000: continue
        for attempt in range(3):
            try:
                await edge_tts.Communicate(text, VOICE, rate=RATE).save(p); break
            except Exception as e:
                print("retry", cid, e)
        print("ok", cid)

def main():
    items = chunks(); assert len(items) > 50, "failed to parse content.mjs"
    if "--measure" not in sys.argv:
        try: asyncio.run(synth(items))
        except ImportError: sys.exit("edge-tts not installed: pip install edge-tts   (or record files yourself and use --measure)")
    timing, missing = {}, []
    for cid, _ in items:
        p = os.path.join(AUDIO, cid + ".mp3")
        if os.path.exists(p): timing[cid] = round(dur(p), 3)
        else: missing.append(cid)
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    json.dump(timing, open(os.path.join(ROOT, "build", "timing.json"), "w"), indent=1)
    print(f"measured {len(timing)} files, missing {len(missing)}", missing[:5])
main()
