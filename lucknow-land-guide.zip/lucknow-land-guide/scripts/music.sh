#!/usr/bin/env bash
# Synthesizes an original soft ambient pad (no third-party music -> no licensing issue). ~11.5 min, mono.
set -e
cd "$(dirname "$0")/.."
D=700
ffmpeg -y -loglevel error \
 -f lavfi -i "sine=f=130.81:d=$D" -f lavfi -i "sine=f=196.00:d=$D" -f lavfi -i "sine=f=261.63:d=$D" -f lavfi -i "sine=f=329.63:d=$D" -f lavfi -i "sine=f=392.00:d=$D" \
 -filter_complex "[0][1][2][3][4]amix=inputs=5:normalize=0,tremolo=f=0.12:d=0.5,lowpass=f=1100,aecho=0.8:0.7:900:0.35,volume=0.5,afade=t=in:d=5,afade=t=out:st=$((D-8)):d=8" \
 -ac 1 -c:a libmp3lame -b:a 64k assets/music/bg.mp3
echo "wrote assets/music/bg.mp3"
