// Generates index.html (HyperFrames composition) + build/report.json + subtitles.srt
// Usage: node scripts/build.mjs
import fs from "node:fs";
import path from "node:path";
import { SCENES } from "../src/content.mjs";
import { scenes } from "../src/scenes.mjs";

const ROOT = path.resolve(import.meta.dirname, "..");
const exists = (p) => fs.existsSync(path.join(ROOT, p));
const FPS = 30, LEAD = 0.7, GAP = 0.3, TAIL = 1.0;
const timing = exists("build/timing.json") ? JSON.parse(fs.readFileSync(path.join(ROOT, "build/timing.json"), "utf8")) : {};
const pad = (n) => String(n).padStart(2, "0");
const est = (t) => Math.max(1.8, t.split(/\s+/).length / 3.0 + 0.4); // fallback when no audio measured
const round = (x) => Math.round(x * FPS) / FPS;

let cursor = 0, captions = [], audio = [], sceneOut = [], missing = [], estimated = 0;
const sceneTimes = [];
SCENES.forEach((sc, si) => {
  const S = round(cursor);
  let off = LEAD; const ch = [];
  sc.chunks.forEach((text, ci) => {
    const id = `s${pad(sc.n)}_c${pad(ci)}`;
    const hasAudio = exists(`assets/audio/${id}.mp3`);
    let dur = timing[id];
    if (!dur) { dur = est(text); estimated++; }
    if (!hasAudio) missing.push(id);
    ch.push(off);
    const t0 = round(S + off);
    if (hasAudio) audio.push({ id, t0, dur });
    // split long captions at Hindi/ASCII commas into <=95 char pieces, timed proportionally
    const parts = []; let cur = "";
    for (const piece of text.split(/(?<=[,،])\s*/)) {
      if ((cur + " " + piece).trim().length > 95 && cur) { parts.push(cur.trim()); cur = piece; } else cur = (cur + " " + piece).trim();
    }
    if (cur) parts.push(cur.trim());
    const total = parts.reduce((a, p) => a + p.length, 0); let acc = 0;
    parts.forEach((p) => {
      const d0 = dur * acc / total; acc += p.length; const d1 = dur * acc / total;
      captions.push({ t0: round(t0 + d0), dur: Math.max(0.5, round(d1 - d0)), text: p });
    });
    off += dur + GAP;
  });
  const D = round(off + TAIL);
  sceneTimes.push({ n: sc.n, S, D, ch });
  const { html, js } = scenes[si](S, ch, D);
  sceneOut.push({ S, D, n: sc.n, html, js });
  cursor = S + D;
});
const TOTAL = round(cursor);

const fontLocal = exists("assets/fonts/NotoSansDevanagari.ttf");
const css = fs.readFileSync(path.join(ROOT, "src/style.css"), "utf8");
const hasMusic = exists("assets/music/bg.mp3");

const html = `<!doctype html>
<html lang="hi"><head><meta charset="utf-8"><title>Lucknow Mein Zameen Kharidne Se Pehle 14 Documents</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>${fontLocal ? `@font-face{font-family:'NotoDevLocal';src:url('assets/fonts/NotoSansDevanagari.ttf');font-weight:100 900;}` : ""}
${css}</style></head>
<body>
<div id="root" data-composition-id="lucknow-land-guide" data-start="0" data-duration="${TOTAL}" data-width="1920" data-height="1080">
  <div id="bg"></div>
${sceneOut.map((s) => `  <section id="sc${s.n}" class="clip scene" data-start="${s.S}" data-duration="${s.D}" data-track-index="0">${s.html}</section>`).join("\n")}
${captions.map((c, i) => `  <div class="clip cap" id="cap${i}" data-start="${c.t0}" data-duration="${c.dur}" data-track-index="1"><span>${c.text}</span></div>`).join("\n")}
${audio.map((a) => `  <audio id="a_${a.id}" src="assets/audio/${a.id}.mp3" data-start="${a.t0}" data-duration="${round(a.dur)}" data-track-index="3" data-volume="1"></audio>`).join("\n")}
${hasMusic ? `  <audio id="music" src="assets/music/bg.mp3" data-start="0" data-duration="${TOTAL}" data-track-index="4" data-volume="0.12"></audio>` : ""}
  <script src="https://cdn.jsdelivr.net/npm/gsap@3/dist/gsap.min.js"></script>
  <script>
  const tl = gsap.timeline({ paused: true });
  tl.to("#bg",{backgroundPosition:"100% 100%",duration:${TOTAL},ease:"none"},0);
${sceneOut.map((s) => `  // ---- Scene ${s.n}
  tl.fromTo("#sc${s.n}",{opacity:0},{opacity:1,duration:.5,ease:"none"},${s.S});
  tl.to("#sc${s.n}",{opacity:0,duration:.5,ease:"none"},${round(s.S + s.D - 0.5)});
${s.js}`).join("\n")}
${captions.map((c, i) => `  tl.from("#cap${i} span",{y:20,opacity:0,duration:.25},${c.t0});`).join("\n")}
  window.__timelines = window.__timelines || {};
  window.__timelines["lucknow-land-guide"] = tl;
  </script>
</div></body></html>`;
fs.writeFileSync(path.join(ROOT, "index.html"), html);

// SRT subtitles (also useful as a sidecar file)
const ts = (t) => { const ms = Math.round(t * 1000); const f = (n, l = 2) => String(n).padStart(l, "0"); return `${f(Math.floor(ms / 3600000))}:${f(Math.floor(ms / 60000) % 60)}:${f(Math.floor(ms / 1000) % 60)},${f(ms % 1000, 3)}`; };
fs.mkdirSync(path.join(ROOT, "build"), { recursive: true });
fs.writeFileSync(path.join(ROOT, "build/subtitles.srt"), captions.map((c, i) => `${i + 1}\n${ts(c.t0)} --> ${ts(c.t0 + c.dur)}\n${c.text}\n`).join("\n"));
fs.writeFileSync(path.join(ROOT, "build/report.json"), JSON.stringify({ totalSeconds: TOTAL, minutes: +(TOTAL / 60).toFixed(2), fps: FPS, scenes: sceneTimes.map((s) => ({ n: s.n, start: s.S, dur: s.D })), captions: captions.length, narrationClips: audio.length, missingAudio: missing.length, timingsEstimatedForChunks: estimated, music: hasMusic }, null, 1));

console.log(`index.html written: ${TOTAL.toFixed(1)}s (${(TOTAL / 60).toFixed(1)} min), ${captions.length} captions`);
if (missing.length) console.warn(`WARNING: ${missing.length} narration files missing in assets/audio/ -> video will render WITHOUT narration for those chunks (timings are estimated). Run: npm run tts   (or add recorded files, then: npm run measure)`);
if (!hasMusic) console.warn("WARNING: assets/music/bg.mp3 missing -> run: npm run music");
if (!fontLocal) console.warn("NOTE: assets/fonts/NotoSansDevanagari.ttf not found -> using Google Fonts CDN (needs internet while rendering).");
